/**
 * Dasboard Routes
 */
import React, { Component } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';


//Reloadable card
import {InductsForTheDayWidget,
	WaveStatusWidget,
	InductsForTheLastHourWidget,
	SortsForTheDayWidget,
	SortsForTheLastHourWidget,
	SortersWidget,
	WatchesWidget,
	InductionStatusWidget,
	ChuteStatusWidget} from "Components/Widgets";

// intl messages
import IntlMessages from 'Util/IntlMessages';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

//Chute Status Overview
import ChuteStatusOverview from 'Components/KPI/ChuteStatusOverview'; 

export default class SorterDetails extends Component {

   linkState = this.props.location.state === undefined ? '' : this.props.location.state.data; 

   render() {
      const { match } = this.props;
      return (
         <div className="ecom-dashboard-wrapper">
            <PageTitleBar title={<IntlMessages id={this.linkState} />} match={match} />
            <div className="row">
            	<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4">
					<InductsForTheDayWidget sorterRoute={'/' + this.linkState} />
					<InductsForTheLastHourWidget sorterRoute={'/' + this.linkState} />
					<SortsForTheDayWidget sorterRoute={'/' + this.linkState} />
					<SortsForTheLastHourWidget sorterRoute={'/' + this.linkState} />
            	</div>
            	<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 col-class-right-sorter">
            		<WatchesWidget />
            		<InductionStatusWidget />
					<ChuteStatusOverview sorterRoute={'/' + this.linkState} nextLink={this.linkState}/> 
            	</div>
            </div>
         </div>
      )
   }
}


