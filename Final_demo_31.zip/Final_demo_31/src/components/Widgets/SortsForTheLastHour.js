/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import {baseURL} from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import ReactSpeedometer from "react-d3-speedometer";

class SortsForTheLastHour extends Component {

	state = {
			data: {},
			label: [],
			graphData: []
	}

	componentDidMount() {
		this.getRecentOrders();
	}

	// recent orders
	getRecentOrders() {
		api.get(baseURL+'inductsforlasthour/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
		 .then(res => {
			    console.log(res.data);
			    let label = res.data.inductsForLastHour.map(list => list.currentHour);
			    let graphData = res.data.inductsForLastHour.map(list => list.currValue);
			    
			    console.log(graphData);
		        this.setState({ data: res.data,
		        				label: label,
		        				graphData: graphData,
					        	isLoading:false}); })
			.catch(function (error) {
				console.log(error);
		  });
	}

	render() {
		const { recentOrders } = this.state;
		const percentage  = this.state.data.percentValue

		return (
				<RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={"Sorts for the last hour"}
				fullBlock
				>
					<div className="clearfix">
	                <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
	                    <div className="d-flex">
	                        <div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
	                        <ReactSpeedometer
		                        segments={3} 
								 width={130} 
								 height={100} 
								 ringWidth={10}
								 minValue={0} 
								 maxValue={100}
								 value={this.state.data.percentValue}
								 needleHeightRatio={0.5}
		                         currentValueText="${value} %"
		                    />
	                        </div>
	                        <div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
	                                <span className="counter-point">
	                                	{this.state.data.currentValue} / {this.state.data.goalValue}
	                                    {/*<IntlMessages id="widgets.weekly" /> / <IntlMessages id="widgets.monthly" />*/}
	                                </span>
	                            </div>
	                            <div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
								<div className="lastdays-text">Last 5 Days</div>
	                                <TinyAreaChart
	                                    label="Visitors"
	                                    chartdata={this.state.graphData}
	                                    labels={this.state.label}
	                                    backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
	                                    borderColor={hexToRgbA(ChartConfig.color.primary, 3)}
	                                    lineTension="0"
	                                    height={130}
	                                    gradient
	                                />
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </RctCollapsibleCard>
		);
	}
}

export default SortsForTheLastHour;
